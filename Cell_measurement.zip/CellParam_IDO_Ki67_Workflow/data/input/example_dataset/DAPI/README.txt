Place DAPI images in this folder.
