Place Ki67 fluorescence images in this folder.
