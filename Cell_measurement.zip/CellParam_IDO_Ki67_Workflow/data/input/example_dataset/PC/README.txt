Place phase-contrast or brightfield images in this folder.
