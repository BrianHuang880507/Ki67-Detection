Place IDO fluorescence images in this folder.
