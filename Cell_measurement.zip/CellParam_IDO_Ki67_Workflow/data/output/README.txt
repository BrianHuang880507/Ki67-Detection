Pipeline outputs will be created under this directory after execution.
