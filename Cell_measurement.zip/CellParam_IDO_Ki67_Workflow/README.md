# 細胞參數分析流程操作手冊

## 1. 主要功能

- 細胞形態學參數計算
- IDO 螢光訊號量測
- Ki67 陽性判定

## 2. 內容說明

- `main.py` 為主要執行入口
- `ki67dtc/` 為流程程式模組
- `data/` 為建議使用之資料夾架構範例

## 3. 系統需求

建議環境如下：

- 作業系統：Windows 10 / Windows 11
- Python：3.10
- Java：OpenJDK 11
- 套件管理：建議使用 `mamba` 或 `conda`

## 4. 安裝步驟

### 4.1 建立環境

建議使用以下指令建立新環境：

```bash
mamba create -n ki67 python=3.10 pyimagej openjdk=11 pip -c conda-forge -y
mamba activate ki67
```

### 4.2 安裝 Python 套件

進入本壓縮包所在目錄後，執行：

```bash
pip install -r requirements.txt
```

### 4.3 Windows 環境變數設定

若在 Windows 上執行時遇到 OpenMP 或重複載入問題，建議設定：

```bash
conda env config vars set KMP_DUPLICATE_LIB_OK=TRUE
mamba deactivate
mamba activate ki67
```

## 5. 外部模型說明

本壓縮包**不包含** segmentation 模型資料夾 `model/`。

本流程中的胞質 segmentation 會呼叫：

- `model/model_BDL6_label_new`

因此，若要從原始影像一路執行 segmentation，需由使用者另外準備 `model/` 資料夾，並放在與 `main.py` 同一層目錄。

若未提供 `model/`，則：

- 可閱讀流程邏輯
- 可保留程式作為分析方法說明
- 但無法直接從原始影像完整重跑 segmentation

## 6. 輸入資料夾結構

建議資料夾結構如下：

```text
data/
  input/
    example_dataset/
      PC/
      DAPI/
      IDO/
      KI67/
  output/
```

各資料夾用途如下：

- `PC/`：相差或明場影像，用於細胞外形 segmentation
- `DAPI/`：細胞核影像
- `IDO/`：IDO 螢光影像
- `KI67/`：Ki67 螢光影像

說明：

- 若不進行 Ki67 判定，可不放 `KI67/`
- 若不進行 IDO 或其他螢光量測，可不放 `IDO/`
- 若有其他螢光通道，可依流程邏輯另行擴充

## 7. 執行方式

### 7.1 基本指令

在本壓縮包根目錄執行：

```bash
python main.py --data_folder example_dataset --nuc_source dapi --fluor_analy --ki67
```

### 7.2 常見執行情境

#### 情境 A：執行細胞參數 + IDO + Ki67

```bash
python main.py --data_folder example_dataset --nuc_source dapi --fluor_analy --ki67
```

#### 情境 B：執行細胞參數 + IDO，不做 Ki67

```bash
python main.py --data_folder example_dataset --nuc_source dapi --fluor_analy
```

#### 情境 C：只做細胞參數，不做螢光與 Ki67

```bash
python main.py --data_folder example_dataset --nuc_source dapi
```

## 8. 參數說明

`main.py` 目前支援以下參數：

### `--data_folder`

用途：

- 指定資料夾名稱或完整路徑

說明：

- 若填入 `example_dataset`，程式會預設到 `data/input/example_dataset/` 尋找資料
- 也可直接填入完整絕對路徑

### `--nuc_source`

可選值：

- `pc`
- `dapi`

預設值：

- `dapi`

用途：

- 指定 nucleus segmentation 來源

建議：

- 一般情況建議使用 `dapi`

### `--fluor_analy`

用途：

- 啟用螢光分析

說明：

- 啟用後，流程會尋找資料夾中的螢光通道資料夾
- 目前主流程可辨識的螢光資料夾名稱為：
    - `DF`
    - `LT`
    - `IDO`

### `--ki67`

用途：

- 啟用 Ki67 陽性判定

說明：

- 啟用後，流程會讀取 `KI67/` 資料夾內的影像

### `--ki67_backend`

可選值：

- `pyimagej`
- `opencv`

預設值：

- `pyimagej`

用途：

- 指定 Ki67 二值化方法

建議：

- 若環境完整且 Java / PyImageJ 可正常使用，建議維持 `pyimagej`

### `--clean_temp`

用途：

- 清除流程產生的中間檔案

建議：

- 第一次測試流程時，建議先不要加此參數，以便檢查中間結果
- 正式批次執行完成後，再視需要使用

## 9. 流程步驟說明

本流程主要分成四步：

### Step 1. segmentation

執行細胞質與細胞核 segmentation。

### Step 2. segmentation 結果轉 outlines

將 segmentation 輸出轉為文字輪廓檔。

### Step 3. 合併 nucleus 與 cytoplasm outlines

建立一一對應的細胞核與胞質輪廓。

### Step 4. 分析與輸出

輸出：

- 細胞形態學參數
- IDO 量測結果
- Ki67 陽性判定結果

## 10. 主要輸出位置

流程執行後，結果會輸出到：

```text
data/output/
```

常見子資料夾包括：

- `data/output/segment/`
- `data/output/outline/`
- `data/output/results/`

其中最常使用的是：

- `data/output/results/<dataset_name>/`

## 11. 結果檔案說明

常見結果檔如下：

- `*_final.csv`
- `<dataset_name>_cleaned.csv`

其中：

- `<dataset_name>_cleaned.csv` 為最終整理後之主結果檔
- 每一列代表一顆細胞
- 會整合形態學欄位、IDO 欄位與 Ki67 判定欄位

## 12. IDO 欄位定義

目前主流程的 IDO 欄位如下：

- `IDO_BackgroundMean`
- `IDO_MeanIntensity`
- `IDO_MeanIntensity_BgSub`
- `IDO_IntDen`
- `IDO_IntDen_BgSub`

其定義為：

- `IDO_BackgroundMean`：每張影像非細胞像素亮度中位數
- `IDO_MeanIntensity`：每顆細胞胞質區域平均亮度
- `IDO_MeanIntensity_BgSub = IDO_MeanIntensity - IDO_BackgroundMean`
- `IDO_IntDen = IDO_MeanIntensity_BgSub`
- `IDO_IntDen_BgSub = Area_cyto × IDO_MeanIntensity_BgSub`

## 13. Ki67 欄位定義

- `ki67_positive = 1`：判定為 Ki67 陽性
- `ki67_positive = 0`：判定為 Ki67 陰性
